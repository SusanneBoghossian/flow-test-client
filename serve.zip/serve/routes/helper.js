'use strict';

exports.getAuthToken = function (clientId, clientSecret) {
    var token = clientId + ':' + clientSecret;
    var hash = new Buffer(token).toString('base64');
    return hash;
};